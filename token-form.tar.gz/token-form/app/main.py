import os, sqlite3, uuid, json, smtplib, csv
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

app = FastAPI(title="Secure Data Collection")

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
DB_PATH  = os.getenv("DB_PATH",  "/app/data/submissions.db")
ADMIN_KEY = os.getenv("ADMIN_KEY", "change-me-secret")

# ── SMTP settings (from env) ─────────────────────────────────────────────────
SMTP_HOST = os.getenv("SMTP_HOST", "localhost")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SMTP_FROM = os.getenv("SMTP_FROM", "no-reply@example.com")
SMTP_TLS  = os.getenv("SMTP_TLS", "true").lower() == "true"

templates = Jinja2Templates(directory="/app/templates")

# ── DB init ───────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS tokens (
                token      TEXT PRIMARY KEY,
                email      TEXT NOT NULL,
                label      TEXT,
                used       INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                used_at    TEXT
            );
            CREATE TABLE IF NOT EXISTS submissions (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                token        TEXT NOT NULL,
                email        TEXT NOT NULL,
                payload      TEXT NOT NULL,
                submitted_at TEXT NOT NULL,
                ip           TEXT
            );
        """)

init_db()

# ── Token helpers ─────────────────────────────────────────────────────────────
def create_token(email: str, label: str = "") -> str:
    token = uuid.uuid4().hex
    with get_db() as conn:
        conn.execute(
            "INSERT INTO tokens(token, email, label, created_at) VALUES(?,?,?,?)",
            (token, email, label, datetime.utcnow().isoformat())
        )
    return token

def get_token_row(token: str):
    with get_db() as conn:
        return conn.execute("SELECT * FROM tokens WHERE token=?", (token,)).fetchone()

def mark_used(token: str):
    with get_db() as conn:
        conn.execute(
            "UPDATE tokens SET used=1, used_at=? WHERE token=?",
            (datetime.utcnow().isoformat(), token)
        )

# ── Email ─────────────────────────────────────────────────────────────────────
def send_email(to: str, link: str, label: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = "Пожалуйста, заполните форму"
    msg["From"]    = SMTP_FROM
    msg["To"]      = to
    html = f"""
    <html><body style="font-family:sans-serif;padding:32px;color:#28251d">
      <h2>Здравствуйте, {label or to}!</h2>
      <p>Вас просят заполнить защищённую форму сбора данных.<br>
      Ссылка действительна <strong>один раз</strong>.</p>
      <p style="margin:24px 0">
        <a href="{link}" style="background:#01696f;color:#fff;padding:12px 24px;
           border-radius:6px;text-decoration:none;font-weight:600">
          Перейти к форме
        </a>
      </p>
      <p style="color:#7a7974;font-size:13px">{link}</p>
    </body></html>"""
    msg.attach(MIMEText(html, "html"))
    try:
        if SMTP_TLS:
            s = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
            s.starttls()
        else:
            s = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT)
        if SMTP_USER:
            s.login(SMTP_USER, SMTP_PASS)
        s.sendmail(SMTP_FROM, [to], msg.as_string())
        s.quit()
        return True
    except Exception as e:
        print(f"[SMTP ERROR] {e}")
        return False

# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/form/{token}", response_class=HTMLResponse)
async def show_form(request: Request, token: str):
    row = get_token_row(token)
    if not row:
        raise HTTPException(status_code=404, detail="Ссылка не найдена")
    if row["used"]:
        return templates.TemplateResponse("expired.html", {"request": request})
    return templates.TemplateResponse("form.html", {
        "request": request,
        "token": token,
        "email": row["email"],
        "label": row["label"] or ""
    })


class FormData(BaseModel):
    token: str
    fields: dict

@app.post("/submit")
async def submit_form(data: FormData, request: Request):
    row = get_token_row(data.token)
    if not row:
        raise HTTPException(status_code=404)
    if row["used"]:
        raise HTTPException(status_code=410, detail="Ссылка уже использована")
    ip = request.client.host if request.client else "unknown"
    with get_db() as conn:
        conn.execute(
            "INSERT INTO submissions(token,email,payload,submitted_at,ip) VALUES(?,?,?,?,?)",
            (data.token, row["email"], json.dumps(data.fields, ensure_ascii=False),
             datetime.utcnow().isoformat(), ip)
        )
    mark_used(data.token)
    return {"status": "ok"}


# ── Admin endpoints (protected by ADMIN_KEY header) ──────────────────────────

def check_admin(request: Request):
    if request.headers.get("X-Admin-Key") != ADMIN_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")

class BulkRequest(BaseModel):
    recipients: list[dict]   # [{"email": "...", "label": "..."}]
    send_emails: bool = True

@app.post("/admin/generate")
async def admin_generate(req: BulkRequest, request: Request):
    check_admin(request)
    results = []
    for r in req.recipients:
        email = r.get("email", "").strip()
        label = r.get("label", "").strip()
        if not email:
            continue
        token = create_token(email, label)
        link  = f"{BASE_URL}/form/{token}"
        sent  = False
        if req.send_emails:
            sent = send_email(email, link, label)
        results.append({"email": email, "token": token, "link": link, "sent": sent})
    return results


@app.get("/admin/submissions")
async def admin_submissions(request: Request):
    check_admin(request)
    with get_db() as conn:
        rows = conn.execute(
            "SELECT s.id, s.email, s.payload, s.submitted_at, s.ip, t.label "
            "FROM submissions s JOIN tokens t ON s.token=t.token "
            "ORDER BY s.submitted_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]


@app.get("/admin/export")
async def admin_export(request: Request):
    """Export CSV of all submissions."""
    check_admin(request)
    path = "/app/data/export.csv"
    with get_db() as conn:
        rows = conn.execute(
            "SELECT s.id, s.email, t.label, s.payload, s.submitted_at, s.ip "
            "FROM submissions s JOIN tokens t ON s.token=t.token "
            "ORDER BY s.submitted_at DESC"
        ).fetchall()
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id","email","label","payload","submitted_at","ip"])
        for r in rows:
            writer.writerow([r["id"], r["email"], r["label"],
                             r["payload"], r["submitted_at"], r["ip"]])
    return FileResponse(path, media_type="text/csv", filename="submissions.csv")


@app.get("/admin/tokens")
async def admin_tokens(request: Request):
    check_admin(request)
    with get_db() as conn:
        rows = conn.execute(
            "SELECT token, email, label, used, created_at, used_at FROM tokens ORDER BY created_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]
