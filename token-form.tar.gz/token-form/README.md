# Secure Token Form — самохостинговый сбор персональных данных

Одноразовые персонализированные ссылки для сбора персональных данных без сторонних сервисов.

## Стек
- **Python 3.12 + FastAPI** — backend
- **SQLite** — хранилище (можно заменить на PostgreSQL)
- **Jinja2** — шаблоны форм
- **Docker / docker-compose** — деплой

## Архитектура

```
[Рассылка Email]
    ↓  уникальная ссылка: https://forms.you.com/form/<uuid_token>
[Пользователь открывает форму]
    ↓  GET /form/<token> — проверка токена в БД
[Заполняет и отправляет]
    ↓  POST /submit — данные → submissions, токен → used=1
[Ссылка становится недействительной]
    ↓  повторный GET /form/<token> → страница "Ссылка недействительна"
[Администратор]
    → GET /admin/submissions  (X-Admin-Key: ...)  — просмотр ответов
    → GET /admin/export                           — выгрузка CSV
    → GET /admin/tokens                           — статус всех токенов
```

## Быстрый старт

### 1. Настройка
```bash
cp docker-compose.yml docker-compose.override.yml
# Отредактируйте BASE_URL, ADMIN_KEY, SMTP_* в docker-compose.yml
```

### 2. Запуск
```bash
docker-compose up -d --build
```

### 3. Подготовьте список получателей
```csv
# recipients.csv
email,label
ivan@example.com,Иванов Иван
maria@example.com,Петрова Мария
```

### 4. Генерация токенов и рассылка
```bash
# Только создать ссылки (без отправки email)
python generate_tokens.py --url http://localhost:8000 \
                          --key ваш-admin-key \
                          --file recipients.csv

# Создать ссылки И отправить письма
python generate_tokens.py --url http://localhost:8000 \
                          --key ваш-admin-key \
                          --file recipients.csv \
                          --send
```

Результат записывается в `generated_links.csv`.

### 5. Просмотр ответов
```bash
# JSON в консоль
curl -H "X-Admin-Key: ваш-admin-key" http://localhost:8000/admin/submissions

# Выгрузка CSV
curl -H "X-Admin-Key: ваш-admin-key" http://localhost:8000/admin/export -o submissions.csv

# Статус токенов
curl -H "X-Admin-Key: ваш-admin-key" http://localhost:8000/admin/tokens
```

## Кастомизация формы
Поля формы находятся в `app/templates/form.html` в блоке, отмеченном комментарием:
```html
<!-- ═══ НАСТРОЙТЕ ПОЛЯ ПОД СВОИ НУЖДЫ ═══ -->
...
<!-- ═══════════════════════════════════════ -->
```

Добавляйте/убирайте `<input>` с нужными `name` атрибутами — они автоматически попадут в `payload` JSON в БД.

## Nginx (обратный прокси)
```nginx
server {
    listen 443 ssl;
    server_name forms.example.com;
    ssl_certificate /etc/letsencrypt/live/forms.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/forms.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Безопасность
- Токен — UUID4 (128 бит энтропии), угадать нельзя
- `ADMIN_KEY` передаётся только в заголовке `X-Admin-Key`
- Данные хранятся только на вашем сервере (SQLite в volume)
- После отправки формы токен немедленно инвалидируется
- Рекомендуется: HTTPS, fail2ban на /submit, ограничение IP на /admin/*

## Структура файлов
```
token-form/
├── app/
│   ├── main.py                 # FastAPI приложение
│   └── templates/
│       ├── form.html           # Форма сбора данных
│       └── expired.html        # Страница «ссылка недействительна»
├── data/                       # SQLite (создаётся автоматически)
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── generate_tokens.py          # CLI для генерации и рассылки
├── recipients_example.csv      # Пример списка получателей
└── README.md
```
