#!/usr/bin/env python3
"""
Скрипт генерации токенов и рассылки писем.

Использование:
  python generate_tokens.py --url http://localhost:8000 \
                            --key ваш-admin-key \
                            --file recipients.csv \
                            [--send]

CSV-формат (recipients.csv):
  email,label
  ivan@example.com,Иванов Иван
  maria@example.com,Мария Петрова

Флаг --send отправляет email через API. Без него — только генерирует ссылки.
"""
import argparse, csv, json, sys
import urllib.request, urllib.error

def main():
    p = argparse.ArgumentParser(description="Token generator for secure form")
    p.add_argument("--url",  required=True, help="Base URL приложения")
    p.add_argument("--key",  required=True, help="ADMIN_KEY")
    p.add_argument("--file", required=True, help="CSV с колонками email,label")
    p.add_argument("--send", action="store_true", help="Отправлять email (иначе только ссылки)")
    args = p.parse_args()

    with open(args.file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    payload = json.dumps({
        "recipients": rows,
        "send_emails": args.send
    }).encode()

    req = urllib.request.Request(
        f"{args.url}/admin/generate",
        data=payload,
        headers={"Content-Type": "application/json", "X-Admin-Key": args.key},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req) as resp:
            results = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"Ошибка {e.code}: {e.read().decode()}", file=sys.stderr)
        sys.exit(1)

    out_file = "generated_links.csv"
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["email", "label", "token", "link", "sent"])
        for r in results:
            w.writerow([r["email"], r.get("label",""), r["token"], r["link"],
                        "да" if r.get("sent") else "нет"])
            print(f"  {r['email']:35s}  {r['link']}")

    print(f"\n✓ Создано {len(results)} токенов. Ссылки сохранены в {out_file}")

if __name__ == "__main__":
    main()
